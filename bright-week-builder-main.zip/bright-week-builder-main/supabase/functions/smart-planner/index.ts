// Smart Planner edge function
// Two modes:
//   { mode: "parse", text: string }  -> returns a weekly schedule mapped to days
//   { mode: "insights", weeks: [...] } -> returns insights & recommendations

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;

const PARSE_TOOL = {
  type: "function",
  function: {
    name: "build_weekly_schedule",
    description:
      "Parse the user's freeform schedule text (could be from an Excel sheet, notes, or a timetable) into a structured Mon–Sun weekly plan. Map each activity to the most appropriate day(s) and time slots. If a row applies to weekdays, repeat it for Mon–Fri. Use 24h HH:MM times. Keep activity labels short and kid-friendly.",
    parameters: {
      type: "object",
      properties: {
        days: {
          type: "object",
          properties: Object.fromEntries(
            DAY_KEYS.map((k) => [
              k,
              {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    label: { type: "string" },
                    start: { type: "string", description: "HH:MM 24h, optional" },
                    end: { type: "string", description: "HH:MM 24h, optional" },
                  },
                  required: ["label"],
                  additionalProperties: false,
                },
              },
            ])
          ),
          required: [...DAY_KEYS],
          additionalProperties: false,
        },
        notes: { type: "string", description: "Short summary of what was parsed." },
      },
      required: ["days", "notes"],
      additionalProperties: false,
    },
  },
};

const INSIGHTS_TOOL = {
  type: "function",
  function: {
    name: "weekly_insights",
    description:
      "Analyze a kid's weekly study/activity completion data and produce friendly, actionable insights and pattern-based recommendations.",
    parameters: {
      type: "object",
      properties: {
        summary: { type: "string", description: "1-2 sentence friendly overview." },
        strengths: {
          type: "array",
          items: { type: "string" },
          description: "What's going well, e.g. 'Strong in Maths'.",
        },
        improvements: {
          type: "array",
          items: { type: "string" },
          description: "What needs more focus, e.g. 'Need more reading time'.",
        },
        recommendations: {
          type: "array",
          items: { type: "string" },
          description: "Concrete schedule tweaks (max 5).",
        },
      },
      required: ["summary", "strengths", "improvements", "recommendations"],
      additionalProperties: false,
    },
  },
};

const CHAT_EDIT_TOOL = {
  type: "function",
  function: {
    name: "update_weekly_schedule",
    description:
      "Apply the user's natural-language request to the current weekly schedule. You may add, remove, rename, retime or rearrange activities on any day(s). When inserting a new activity into a busy day, shift surrounding activities to avoid time clashes, keeping the overall structure intact. Return the FULL updated week for all 7 days (not just changes). Use 24h HH:MM times.",
    parameters: {
      type: "object",
      properties: {
        days: {
          type: "object",
          properties: Object.fromEntries(
            DAY_KEYS.map((k) => [
              k,
              {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    label: { type: "string" },
                    start: { type: "string" },
                    end: { type: "string" },
                  },
                  required: ["label"],
                  additionalProperties: false,
                },
              },
            ])
          ),
          required: [...DAY_KEYS],
          additionalProperties: false,
        },
        reply: {
          type: "string",
          description: "Friendly 1-2 sentence reply confirming what changed.",
        },
      },
      required: ["days", "reply"],
      additionalProperties: false,
    },
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ error: "LOVABLE_API_KEY is not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const mode = body?.mode;

    let messages: any[] = [];
    let tools: any[] = [];
    let toolChoice: any;

    if (mode === "parse") {
      const text = String(body?.text ?? "").slice(0, 20000);
      if (!text.trim()) {
        return new Response(JSON.stringify({ error: "Empty text" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      messages = [
        {
          role: "system",
          content:
            "You are an assistant that builds weekly schedules for kids. Given a raw schedule (may come from an Excel sheet exported as text, notes, or a timetable), map activities to Monday–Sunday. If the source uses a single weekday template, repeat it Mon–Fri. Keep times in 24h HH:MM. Output via the provided tool only.",
        },
        { role: "user", content: text },
      ];
      tools = [PARSE_TOOL];
      toolChoice = { type: "function", function: { name: "build_weekly_schedule" } };
    } else if (mode === "insights") {
      const weeks = body?.weeks ?? [];
      messages = [
        {
          role: "system",
          content:
            "You analyze a child's weekly study/activity completion. Each activity has a 0–100% completion. Be encouraging, concrete, and specific. Spot patterns across weeks (improving subjects, repeated misses, day-of-week trends). Output via the provided tool only.",
        },
        {
          role: "user",
          content:
            "Here is the recent weekly data as JSON:\n" + JSON.stringify(weeks).slice(0, 18000),
        },
      ];
      tools = [INSIGHTS_TOOL];
      toolChoice = { type: "function", function: { name: "weekly_insights" } };
    } else if (mode === "chat_edit") {
      const message = String(body?.message ?? "").slice(0, 4000);
      const currentDays = body?.days ?? {};
      if (!message.trim()) {
        return new Response(JSON.stringify({ error: "Empty message" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      messages = [
        {
          role: "system",
          content:
            "You edit a kid's weekly study planner from natural-language requests (e.g. 'Add a 30 min piano practice on Wednesday at 4pm', 'Move maths to morning', 'Remove dance on Saturday'). You receive the current week as JSON. When you add a new activity into a slot that already has an activity at that time, automatically shift surrounding activities by 15-30 min to avoid clashes — never overlap times. Preserve any unrelated activities exactly. Always return the FULL updated week for all 7 days via the tool. Be concise in the reply.",
        },
        {
          role: "user",
          content:
            "Current week:\n" +
            JSON.stringify(currentDays).slice(0, 16000) +
            "\n\nRequest: " +
            message,
        },
      ];
      tools = [CHAT_EDIT_TOOL];
      toolChoice = { type: "function", function: { name: "update_weekly_schedule" } };
    } else {
      return new Response(JSON.stringify({ error: "Unknown mode" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }



    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages,
        tools,
        tool_choice: toolChoice,
      }),
    });

    if (!aiRes.ok) {
      if (aiRes.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit hit, try again in a minute." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (aiRes.status === 402) {
        return new Response(
          JSON.stringify({
            error: "AI credits exhausted. Add credits in Settings → Workspace → Usage.",
          }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const t = await aiRes.text();
      console.error("AI gateway error:", aiRes.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await aiRes.json();
    const call = data?.choices?.[0]?.message?.tool_calls?.[0];
    if (!call?.function?.arguments) {
      return new Response(JSON.stringify({ error: "No tool call returned" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const args = JSON.parse(call.function.arguments);
    return new Response(JSON.stringify(args), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("smart-planner error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
