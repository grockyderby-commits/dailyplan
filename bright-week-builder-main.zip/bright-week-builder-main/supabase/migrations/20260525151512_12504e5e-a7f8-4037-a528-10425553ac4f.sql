-- Don't autopopulate student_name from email/oauth metadata anymore.
-- The app will explicitly ask the user for the student's name on first run.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
begin
  insert into public.profiles (user_id, student_name)
  values (new.id, null)
  on conflict (user_id) do nothing;
  return new;
end;
$function$;