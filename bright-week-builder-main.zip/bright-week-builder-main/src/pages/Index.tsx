import { useMemo, useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  ChevronLeft, ChevronRight, Copy, RotateCcw, Sparkles, Save, Trash2, LogOut, Crown, Loader2, LogIn, Undo2, Redo2,
} from "lucide-react";
import { ProgressRing } from "@/components/ProgressRing";
import { DayCard } from "@/components/DayCard";
import { SmartAssistant } from "@/components/SmartAssistant";
import { DAYS, addDays, startOfWeek, DayKey } from "@/lib/planner-data";
import { dayPercent, usePlanner, weekPercent } from "@/hooks/use-planner";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import Landing from "@/pages/Landing";
import { StudentNameSetup } from "@/components/StudentNameSetup";
import { lovable } from "@/integrations/lovable";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const GEM_EMOJIS = ["💎", "🌟", "✨", "🎉", "🏅", "🚀"];
const ENCOURAGEMENT = [
  "Nice start — keep the streak going!",
  "Every step counts. Onwards! 💪",
  "You're moving — small wins add up.",
];
const BONUS = [
  "Incredible! Over 80% done today 🏆",
  "Day champion! You crushed today's plan 🥇",
  "Star performance — over 80% complete! 🌟",
];

const Index = () => {
  const { user, profile, loading: authLoading, signOut, togglePaid, guest, guestStartedAt, endGuest } = useAuth();
  const [anchorDate, setAnchorDate] = useState<Date>(() => new Date());
  const [confirmDelete1, setConfirmDelete1] = useState(false);
  const [confirmDelete2, setConfirmDelete2] = useState(false);
  const [confirmReset1, setConfirmReset1] = useState(false);
  const [confirmReset2, setConfirmReset2] = useState(false);
  const [confirmWipe1, setConfirmWipe1] = useState(false);
  const [confirmWipe2, setConfirmWipe2] = useState(false);

  const planner = usePlanner(anchorDate, user?.id, { guest });
  const {
    store, week, savedWeek, dirty, saving, loading,
    setProgress: rawSetProgress, updateActivity, addActivity, removeActivity,
    copyPreviousWeek, resetWeek, replaceWeekTemplate, replaceDay,
    saveWeek, deleteWeek, deleteAllWeeks,
    hasPreviousWeek, weekStartDate,
    undo, redo, canUndo, canRedo,
  } = planner;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const meta = e.ctrlKey || e.metaKey;
      if (!meta) return;
      const target = e.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA"].includes(target.tagName)) return;
      if (e.key.toLowerCase() === "z" && !e.shiftKey) {
        e.preventDefault();
        if (canUndo) undo();
      } else if ((e.key.toLowerCase() === "y") || (e.key.toLowerCase() === "z" && e.shiftKey)) {
        e.preventDefault();
        if (canRedo) redo();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo, canUndo, canRedo]);

  const today = useMemo(() => { const t = new Date(); t.setHours(0,0,0,0); return t; }, []);
  const weekPct = weekPercent(week);
  const todayKey = useMemo(() => DAYS[(today.getDay() + 6) % 7].key, [today]);
  const todayPct = dayPercent(week, todayKey);

  // Completion feedback: gem on task complete, bonus when day crosses 80%, gentle encouragement otherwise.
  const setProgress = useCallback(
    (day: DayKey, activityId: string, value: number) => {
      const prev = week?.progress?.[day]?.[activityId] ?? 0;
      const prevDayPct = dayPercent(week, day);
      rawSetProgress(day, activityId, value);
      if (value > prev) {
        if (value === 100) {
          const gem = GEM_EMOJIS[Math.floor(Math.random() * GEM_EMOJIS.length)];
          toast.success(`Well done! ${gem}`);
        }
        // Recompute day pct after this change
        if (week) {
          const acts = week.template[day] ?? [];
          if (acts.length) {
            const total = acts.reduce(
              (sum, a) => sum + (a.id === activityId ? value : (week.progress[day][a.id] ?? 0)),
              0
            );
            const newPct = Math.round(total / acts.length);
            if (day === todayKey && prevDayPct < 80 && newPct >= 80) {
              toast.success(BONUS[Math.floor(Math.random() * BONUS.length)], { duration: 4000 });
            } else if (value === 100 && day === todayKey && newPct < 50) {
              toast(ENCOURAGEMENT[Math.floor(Math.random() * ENCOURAGEMENT.length)]);
            }
          }
        }
      }
    },
    [rawSetProgress, week, todayKey]
  );

  const bestDay = useMemo(() => {
    if (!week) return null;
    let best = { key: DAYS[0].key, pct: -1, label: DAYS[0].label, emoji: DAYS[0].emoji };
    DAYS.forEach((d) => {
      const p = dayPercent(week, d.key);
      if (p > best.pct) best = { key: d.key, pct: p, label: d.label, emoji: d.emoji };
    });
    return best;
  }, [week]);

  const weekRangeLabel = useMemo(() => {
    const start = weekStartDate;
    const end = addDays(start, 6);
    const fmt = (d: Date) => d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    return `${fmt(start)} – ${fmt(end)}, ${end.getFullYear()}`;
  }, [weekStartDate]);

  const handleGoogle = async () => {
    const res = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (res.error) toast.error("Sign-in failed. Please try again.");
  };

  // Auth gates
  if (authLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  }
  if (!user && !guest) return <Landing />;
  if (!profile?.student_name) return <StudentNameSetup />;

  const navigateWeek = (delta: number) => {
    if (dirty && !confirm("You have unsaved changes. Leave without saving?")) return;
    setAnchorDate((d) => addDays(d, delta * 7));
  };

  const isCurrentWeek = startOfWeek(today).getTime() === weekStartDate.getTime();

  const handleCopy = () => {
    if (!hasPreviousWeek) return toast.info("No previous week to copy yet 🌱");
    copyPreviousWeek();
    toast.success("Copied last week's activities — review and Save ✨");
  };

  const handleSave = async () => {
    const ok = await saveWeek();
    if (ok) toast.success(guest ? "Saved on this device ✅" : "Week saved ✅");
    else toast.error("Couldn't save week");
  };

  const doReset = () => { resetWeek(); toast.success("Progress reset for this week. Save to keep it 🌟"); };
  const doDeleteWeek = async () => {
    const ok = await deleteWeek();
    if (ok) toast.success("Week deleted");
    else toast.error("Couldn't delete week");
  };
  const doWipeAll = async () => {
    const ok = await deleteAllWeeks();
    if (ok) toast.success("All weeks deleted");
    else toast.error("Couldn't delete all weeks");
  };

  // Guest gentle nudge after 10 minutes
  const guestMinutes = guestStartedAt ? Math.floor((Date.now() - guestStartedAt) / 60000) : 0;
  const showSignInNudge = guest && guestMinutes >= 10;

  return (
    <div className="min-h-screen">
      {guest && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 text-sm">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-2 flex items-center justify-between gap-3 flex-wrap">
            <p className="font-medium">
              {showSignInNudge
                ? "👋 You've been exploring for a bit — sign in with Google to save your week across devices."
                : "You're trying Star Week as a guest. Sign in any time to save your data securely."}
            </p>
            <div className="flex items-center gap-2">
              <Button size="sm" className="rounded-full font-bold h-8" onClick={handleGoogle}>
                <LogIn className="h-3.5 w-3.5 mr-1.5" /> Sign in with Google
              </Button>
              <Button size="sm" variant="ghost" className="rounded-full h-8" onClick={endGuest}>
                Back to home
              </Button>
            </div>
          </div>
        </div>
      )}

      <header className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-rainbow opacity-90" />
        <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-white/20 blur-2xl" />
        <div className="absolute -bottom-16 -left-10 w-56 h-56 rounded-full bg-white/15 blur-2xl" />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-10 text-white">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center text-2xl shadow-soft">🌟</div>
              <div>
                <h1 className="text-3xl sm:text-4xl font-bold tracking-tight" style={{ fontFamily: "Fredoka, sans-serif" }}>
                  {profile.student_name}'s Star Week
                </h1>
                <p className="text-white/85 text-sm">Your weekly adventure planner</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {user && (
                <Button variant="ghost" size="sm" className="rounded-full text-white hover:bg-white/20" onClick={togglePaid}>
                  <Crown className="h-4 w-4 mr-1.5" />
                  {profile.is_paid ? "Paid" : "Free"} plan
                </Button>
              )}
              {user ? (
                <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/20" onClick={signOut} aria-label="Sign out">
                  <LogOut className="h-5 w-5" />
                </Button>
              ) : (
                <Button variant="ghost" size="sm" className="rounded-full text-white hover:bg-white/20" onClick={handleGoogle}>
                  <LogIn className="h-4 w-4 mr-1.5" /> Sign in
                </Button>
              )}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
            <div className="rounded-3xl bg-white/95 text-foreground p-4 flex items-center gap-4 shadow-pop">
              <ProgressRing value={weekPct} size={86} stroke={10} label="Week" />
              <div>
                <p className="text-xs uppercase font-bold text-muted-foreground tracking-wide">This week</p>
                <p className="text-lg font-bold leading-tight">{weekRangeLabel}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {weekPct >= 75 ? "Crushing it! 🔥" : weekPct >= 40 ? "Keep going! 💪" : "Let's begin! 🌱"}
                </p>
              </div>
            </div>
            <div className="rounded-3xl bg-white/95 text-foreground p-4 flex items-center gap-4 shadow-pop">
              <ProgressRing value={todayPct} size={86} stroke={10} label="Today" />
              <div>
                <p className="text-xs uppercase font-bold text-muted-foreground tracking-wide">Today</p>
                <p className="text-lg font-bold leading-tight">{today.toLocaleDateString(undefined, { weekday: "long" })}</p>
                <p className="text-xs text-muted-foreground mt-1">{isCurrentWeek ? "Tap activities to update ✨" : "Browsing another week"}</p>
              </div>
            </div>
            <div className="rounded-3xl bg-white/95 text-foreground p-4 flex items-center gap-4 shadow-pop">
              <div className="w-[86px] h-[86px] rounded-full gradient-sunshine flex items-center justify-center text-4xl shadow-soft">{bestDay?.emoji ?? "🏆"}</div>
              <div>
                <p className="text-xs uppercase font-bold text-muted-foreground tracking-wide">Best day</p>
                <p className="text-lg font-bold leading-tight">{bestDay?.label ?? "—"}</p>
                <p className="text-xs text-muted-foreground mt-1">{bestDay?.pct ?? 0}% completed</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 -mt-4 relative z-10">
        <div className="rounded-2xl bg-card shadow-card p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="ghost" size="icon" onClick={() => navigateWeek(-1)} aria-label="Previous week">
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div className="font-bold text-sm sm:text-base px-2" style={{ fontFamily: "Fredoka, sans-serif" }}>{weekRangeLabel}</div>
            <Button variant="ghost" size="icon" onClick={() => navigateWeek(1)} aria-label="Next week">
              <ChevronRight className="h-5 w-5" />
            </Button>
            {!isCurrentWeek && (
              <Button variant="outline" size="sm" className="ml-1 rounded-full" onClick={() => setAnchorDate(new Date())}>Today</Button>
            )}
            {dirty && (
              <span className="text-[11px] font-bold uppercase tracking-wide bg-amber-100 text-amber-700 px-2 py-1 rounded-full">
                Unsaved
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" className="rounded-full" onClick={undo} disabled={!canUndo} aria-label="Undo">
              <Undo2 className="h-4 w-4 mr-1.5" /> Undo
            </Button>
            <Button variant="outline" size="sm" className="rounded-full" onClick={redo} disabled={!canRedo} aria-label="Redo">
              <Redo2 className="h-4 w-4 mr-1.5" /> Redo
            </Button>
            <Button size="sm" className="rounded-full font-bold" onClick={handleSave} disabled={!dirty || saving}>
              {saving ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
              Save week
            </Button>
            <Button variant="secondary" size="sm" className="rounded-full font-bold" onClick={handleCopy} disabled={!hasPreviousWeek}>
              <Copy className="h-4 w-4 mr-1.5" /> Copy last week
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full" onClick={() => setConfirmReset1(true)}>
              <RotateCcw className="h-4 w-4 mr-1.5" /> Reset progress
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full text-destructive hover:text-destructive" onClick={() => setConfirmDelete1(true)} disabled={!savedWeek}>
              <Trash2 className="h-4 w-4 mr-1.5" /> Delete week
            </Button>
            <Button variant="ghost" size="sm" className="rounded-full text-destructive hover:text-destructive" onClick={() => setConfirmWipe1(true)} disabled={Object.keys(store.weeks).length === 0}>
              <Trash2 className="h-4 w-4 mr-1.5" /> Reset all data
            </Button>
          </div>
        </div>
      </div>

      <SmartAssistant
        store={store}
        week={week}
        onApplySchedule={replaceWeekTemplate}
        onReplaceDay={replaceDay}
      />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>{profile.student_name}'s week</h2>
        </div>

        {loading ? (
          <div className="py-20 text-center text-muted-foreground"><Loader2 className="h-6 w-6 animate-spin mx-auto" /></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5">
            {DAYS.map((d, i) => {
              const date = addDays(weekStartDate, i);
              const isToday = date.getFullYear() === today.getFullYear() && date.getMonth() === today.getMonth() && date.getDate() === today.getDate();
              return (
                <DayCard
                  key={d.key}
                  dayKey={d.key}
                  date={date}
                  week={week}
                  isToday={isToday}
                  onSet={setProgress}
                  onUpdateActivity={updateActivity}
                  onAddActivity={addActivity}
                  onRemoveActivity={removeActivity}
                />
              );
            })}
          </div>
        )}

        <footer className="text-center text-xs text-muted-foreground mt-10 pb-6">
          {guest ? "Saved on this device · Sign in to keep your week safe" : "Saved securely to your account"} · Made with 💖 for curious kids
        </footer>
      </main>

      {/* Delete week — step 1 */}
      <AlertDialog open={confirmDelete1} onOpenChange={setConfirmDelete1}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this week?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the saved schedule and progress for {weekRangeLabel}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep it</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setConfirmDelete1(false); setConfirmDelete2(true); }}>
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={confirmDelete2} onOpenChange={setConfirmDelete2}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The week's data will be permanently deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={async () => { setConfirmDelete2(false); await doDeleteWeek(); }}>
              Yes, delete week
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={confirmReset1} onOpenChange={setConfirmReset1}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset this week's progress?</AlertDialogTitle>
            <AlertDialogDescription>
              All completion ticks for {weekRangeLabel} will be cleared. Activities stay.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setConfirmReset1(false); setConfirmReset2(true); }}>
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={confirmReset2} onOpenChange={setConfirmReset2}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm reset</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure? You'll need to track each activity again. Don't forget to Save afterwards.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setConfirmReset2(false); doReset(); }}>
              Yes, reset progress
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={confirmWipe1} onOpenChange={setConfirmWipe1}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>⚠️ Reset ALL data?</AlertDialogTitle>
            <AlertDialogDescription>
              This deletes <b>every saved week</b> from your account. Daily, weekly, monthly and yearly history will be lost.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setConfirmWipe1(false); setConfirmWipe2(true); }}>
              I understand, continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={confirmWipe2} onOpenChange={setConfirmWipe2}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Final confirmation</AlertDialogTitle>
            <AlertDialogDescription>
              This action is permanent and cannot be undone. Are you really sure you want to wipe all weekly data?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No, keep my data</AlertDialogCancel>
            <AlertDialogAction onClick={async () => { setConfirmWipe2(false); await doWipeAll(); }}>
              Yes, delete everything
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Index;
