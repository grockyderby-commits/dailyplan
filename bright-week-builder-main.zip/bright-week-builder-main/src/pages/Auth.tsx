import { Button } from "@/components/ui/button";
import { lovable } from "@/integrations/lovable";
import { toast } from "sonner";

export default function Auth() {
  const handleGoogle = async () => {
    const res = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (res.error) toast.error("Sign-in failed. Please try again.");
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 gradient-rainbow">
      <div className="w-full max-w-md rounded-3xl bg-card shadow-pop p-8 text-center space-y-6">
        <div className="text-6xl">🌟</div>
        <div>
          <h1 className="text-3xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>
            Star Week
          </h1>
          <p className="text-muted-foreground mt-2">
            Sign in with Google to start your weekly adventure
          </p>
        </div>
        <Button size="lg" className="w-full rounded-full font-bold" onClick={handleGoogle}>
          Continue with Google
        </Button>
        <p className="text-xs text-muted-foreground">
          Your data is private and only visible to you.
        </p>
      </div>
    </div>
  );
}
