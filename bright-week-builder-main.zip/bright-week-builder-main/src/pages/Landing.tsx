import { Button } from "@/components/ui/button";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/use-auth";
import { Sparkles, Brain, Trophy, Calendar, MessageSquare, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

export default function Landing() {
  const { startGuest } = useAuth();

  const handleGoogle = async () => {
    const res = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (res.error) toast.error("Sign-in failed. Please try again.");
  };

  return (
    <div className="min-h-screen">
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-rainbow opacity-95" />
        <div className="absolute -top-16 -right-16 w-72 h-72 rounded-full bg-white/20 blur-3xl" />
        <div className="absolute -bottom-20 -left-10 w-72 h-72 rounded-full bg-white/15 blur-3xl" />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-16 sm:py-24 text-white text-center">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide mb-6">
            <Sparkles className="h-3.5 w-3.5" /> Built for curious learners
          </div>
          <h1
            className="text-4xl sm:text-6xl font-bold tracking-tight"
            style={{ fontFamily: "Fredoka, sans-serif" }}
          >
            Help your child study smarter, every week.
          </h1>
          <p className="mt-5 text-base sm:text-lg text-white/90 max-w-2xl mx-auto">
            Star Week turns scattered school days into a clear, joyful weekly plan — with AI
            scheduling, gentle reminders and rewards that keep kids motivated to finish what
            they start.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button
              size="lg"
              className="rounded-full font-bold bg-white text-foreground hover:bg-white/90"
              onClick={startGuest}
            >
              Try it free — no sign in
            </Button>
            <Button
              size="lg"
              variant="ghost"
              className="rounded-full font-bold text-white border-2 border-white/70 hover:bg-white/15 hover:text-white"
              onClick={handleGoogle}
            >
              Continue with Google
            </Button>
          </div>
          <p className="mt-3 text-xs text-white/80">
            Sign in with Google to save weeks across devices — your data stays private to you.
          </p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
        <h2
          className="text-2xl sm:text-3xl font-bold text-center"
          style={{ fontFamily: "Fredoka, sans-serif" }}
        >
          Why families love Star Week
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
          <FeatureCard
            icon={<Calendar className="h-5 w-5" />}
            title="A clear weekly plan"
            text="See the whole week at a glance, day by day. Kids know exactly what's next — no nagging needed."
          />
          <FeatureCard
            icon={<Brain className="h-5 w-5" />}
            title="Smart AI scheduling"
            text="Paste a timetable or chat naturally — the AI builds and rearranges the plan to fit real life."
          />
          <FeatureCard
            icon={<Trophy className="h-5 w-5" />}
            title="Rewards for finishing"
            text="Earn gems for every completed task and bonus praise when the day's progress passes 80%."
          />
          <FeatureCard
            icon={<MessageSquare className="h-5 w-5" />}
            title="Talk, don't type"
            text="Voice chat with the assistant — natural two-way conversation that explains and motivates."
          />
          <FeatureCard
            icon={<ShieldCheck className="h-5 w-5" />}
            title="Private to your family"
            text="Sign in with Google and your weeks are stored securely under your own account."
          />
          <FeatureCard
            icon={<Sparkles className="h-5 w-5" />}
            title="Built for busy parents"
            text="Used in real homes and learning centres to keep study habits consistent week after week."
          />
        </div>

        <div className="mt-14 rounded-3xl gradient-rainbow text-white p-8 sm:p-10 text-center shadow-pop">
          <h3 className="text-2xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>
            Ready to start the week strong?
          </h3>
          <p className="mt-2 text-white/90 max-w-xl mx-auto text-sm">
            Try it now without signing up. When you're ready to save your progress, sign in with
            Google in one tap.
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
            <Button
              size="lg"
              className="rounded-full font-bold bg-white text-foreground hover:bg-white/90"
              onClick={startGuest}
            >
              Start free
            </Button>
            <Button
              size="lg"
              variant="ghost"
              className="rounded-full font-bold text-white border-2 border-white/70 hover:bg-white/15 hover:text-white"
              onClick={handleGoogle}
            >
              Sign in with Google
            </Button>
          </div>
        </div>

        <footer className="text-center text-xs text-muted-foreground mt-10">
          Made with 💖 for curious kids and supportive parents.
        </footer>
      </main>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  text,
}: {
  icon: React.ReactNode;
  title: string;
  text: string;
}) {
  return (
    <div className="rounded-3xl bg-card shadow-card p-5 border-2 border-transparent hover:border-primary/30 transition-smooth">
      <div className="w-10 h-10 rounded-2xl gradient-rainbow flex items-center justify-center text-white shadow-soft mb-3">
        {icon}
      </div>
      <h3 className="font-bold text-base" style={{ fontFamily: "Fredoka, sans-serif" }}>
        {title}
      </h3>
      <p className="text-sm text-muted-foreground mt-1">{text}</p>
    </div>
  );
}
