import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Profile = {
  id: string;
  user_id: string;
  student_name: string | null;
  is_paid: boolean;
};

const GUEST_KEY = "starweek-guest";
const GUEST_NAME_KEY = "starweek-guest-name";
const GUEST_STARTED_KEY = "starweek-guest-started";

type AuthContextType = {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  guest: boolean;
  guestStartedAt: number | null;
  startGuest: () => void;
  endGuest: () => void;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  setStudentName: (name: string) => Promise<void>;
  togglePaid: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [guest, setGuest] = useState<boolean>(() => localStorage.getItem(GUEST_KEY) === "1");
  const [guestStartedAt, setGuestStartedAt] = useState<number | null>(() => {
    const v = localStorage.getItem(GUEST_STARTED_KEY);
    return v ? parseInt(v, 10) : null;
  });
  const [guestName, setGuestName] = useState<string | null>(() => localStorage.getItem(GUEST_NAME_KEY));

  const loadProfile = async (uid: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", uid)
      .maybeSingle();
    setProfile((data as Profile) ?? null);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        // Once signed in, leave guest mode
        localStorage.removeItem(GUEST_KEY);
        setGuest(false);
        setTimeout(() => loadProfile(s.user.id), 0);
      } else {
        setProfile(null);
      }
    });

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadProfile(s.user.id).finally(() => setLoading(false));
      else setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const startGuest = () => {
    localStorage.setItem(GUEST_KEY, "1");
    const now = Date.now();
    if (!localStorage.getItem(GUEST_STARTED_KEY)) {
      localStorage.setItem(GUEST_STARTED_KEY, String(now));
      setGuestStartedAt(now);
    }
    setGuest(true);
  };
  const endGuest = () => {
    localStorage.removeItem(GUEST_KEY);
    setGuest(false);
  };

  const guestProfile: Profile | null = guest
    ? {
        id: "guest",
        user_id: "guest",
        student_name: guestName,
        is_paid: false,
      }
    : null;

  const value: AuthContextType = {
    user,
    session,
    profile: user ? profile : guestProfile,
    loading,
    guest,
    guestStartedAt,
    startGuest,
    endGuest,
    signOut: async () => {
      await supabase.auth.signOut();
    },
    refreshProfile: async () => {
      if (user) await loadProfile(user.id);
    },
    setStudentName: async (name: string) => {
      if (user) {
        await supabase
          .from("profiles")
          .upsert({ user_id: user.id, student_name: name }, { onConflict: "user_id" });
        await loadProfile(user.id);
      } else if (guest) {
        localStorage.setItem(GUEST_NAME_KEY, name);
        setGuestName(name);
      }
    },
    togglePaid: async () => {
      if (!user || !profile) return;
      await supabase
        .from("profiles")
        .update({ is_paid: !profile.is_paid })
        .eq("user_id", user.id);
      await loadProfile(user.id);
    },
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
