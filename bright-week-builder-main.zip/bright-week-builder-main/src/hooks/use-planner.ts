import { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Activity,
  DayKey,
  DAYS,
  DEFAULT_TEMPLATE,
  startOfWeek,
  weekKey,
} from "@/lib/planner-data";

export type ProgressMap = Record<DayKey, Record<string, number>>;
export type WeekData = {
  weekStart: string;
  template: Record<DayKey, Activity[]>;
  progress: ProgressMap;
};
export type Store = {
  weeks: Record<string, WeekData>;
};

const GUEST_WEEKS_KEY = "starweek-guest-weeks";

const emptyProgress = (): ProgressMap =>
  DAYS.reduce((acc, d) => ({ ...acc, [d.key]: {} }), {} as ProgressMap);

const cloneTemplate = (t: Record<DayKey, Activity[]>): Record<DayKey, Activity[]> =>
  DAYS.reduce(
    (acc, d) => ({ ...acc, [d.key]: (t[d.key] ?? []).map((a) => ({ ...a })) }),
    {} as Record<DayKey, Activity[]>
  );

const ensureShape = (template: any, progress: any) => {
  const t: Record<DayKey, Activity[]> = {} as any;
  const p: ProgressMap = {} as any;
  DAYS.forEach((d) => {
    t[d.key] = Array.isArray(template?.[d.key]) ? template[d.key] : [];
    p[d.key] = (progress?.[d.key] && typeof progress[d.key] === "object") ? progress[d.key] : {};
  });
  return { template: t, progress: p };
};

const loadGuestWeeks = (): Record<string, WeekData> => {
  try {
    const raw = localStorage.getItem(GUEST_WEEKS_KEY);
    if (!raw) return {};
    const obj = JSON.parse(raw);
    const out: Record<string, WeekData> = {};
    Object.entries(obj || {}).forEach(([k, v]: [string, any]) => {
      const s = ensureShape(v?.template, v?.progress);
      out[k] = { weekStart: k, template: s.template, progress: s.progress };
    });
    return out;
  } catch {
    return {};
  }
};

const saveGuestWeeks = (weeks: Record<string, WeekData>) => {
  localStorage.setItem(GUEST_WEEKS_KEY, JSON.stringify(weeks));
};

export function usePlanner(
  currentDate: Date,
  userId: string | undefined,
  opts: { guest?: boolean } = {}
) {
  const isGuest = !!opts.guest && !userId;
  const [store, setStore] = useState<Store>({ weeks: {} });
  const [draft, setDraft] = useState<WeekData | null>(null);
  const [dirty, setDirty] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const key = weekKey(currentDate);
  const initialisedKeys = useRef<Set<string>>(new Set());

  // Undo/redo history (per week key). Capacity 20 to give plenty of headroom.
  const HISTORY_CAP = 20;
  const past = useRef<Record<string, WeekData[]>>({});
  const future = useRef<Record<string, WeekData[]>>({});
  const [, forceTick] = useState(0);
  const bumpHistory = () => forceTick((n) => n + 1);
  const snapshot = (w: WeekData): WeekData => JSON.parse(JSON.stringify(w));
  const pushHistory = (prev: WeekData) => {
    const arr = past.current[prev.weekStart] ?? [];
    arr.push(snapshot(prev));
    if (arr.length > HISTORY_CAP) arr.shift();
    past.current[prev.weekStart] = arr;
    future.current[prev.weekStart] = [];
    bumpHistory();
  };

  // Initial load
  useEffect(() => {
    if (isGuest) {
      setStore({ weeks: loadGuestWeeks() });
      setLoading(false);
      return;
    }
    if (!userId) return;
    setLoading(true);
    supabase
      .from("weeks")
      .select("*")
      .eq("user_id", userId)
      .order("week_start", { ascending: true })
      .then(({ data }) => {
        const weeks: Record<string, WeekData> = {};
        (data ?? []).forEach((row: any) => {
          const shaped = ensureShape(row.template, row.progress);
          weeks[row.week_start] = {
            weekStart: row.week_start,
            template: shaped.template,
            progress: shaped.progress,
          };
        });
        setStore({ weeks });
        setLoading(false);
      });
  }, [userId, isGuest]);

  // Build draft for current week
  useEffect(() => {
    if (loading) return;
    const existing = store.weeks[key];
    if (existing) {
      setDraft({
        weekStart: existing.weekStart,
        template: cloneTemplate(existing.template),
        progress: JSON.parse(JSON.stringify(existing.progress)),
      });
      setDirty(false);
      return;
    }
    const sortedKeys = Object.keys(store.weeks).sort();
    const prevKey = sortedKeys.filter((k) => k < key).pop();
    const template = prevKey
      ? cloneTemplate(store.weeks[prevKey].template)
      : cloneTemplate(DEFAULT_TEMPLATE);
    setDraft({ weekStart: key, template, progress: emptyProgress() });
    setDirty(!initialisedKeys.current.has(key));
    initialisedKeys.current.add(key);
  }, [key, store.weeks, loading]);

  const week = draft ?? undefined;
  const savedWeek = store.weeks[key];

  const mutateDraft = useCallback((fn: (w: WeekData) => WeekData) => {
    setDraft((prev) => {
      if (!prev) return prev;
      pushHistory(prev);
      return fn(prev);
    });
    setDirty(true);
  }, []);

  const undo = useCallback(() => {
    setDraft((prev) => {
      if (!prev) return prev;
      const stack = past.current[prev.weekStart] ?? [];
      if (!stack.length) return prev;
      const last = stack.pop()!;
      past.current[prev.weekStart] = stack;
      (future.current[prev.weekStart] ??= []).push(snapshot(prev));
      bumpHistory();
      setDirty(true);
      return last;
    });
  }, []);

  const redo = useCallback(() => {
    setDraft((prev) => {
      if (!prev) return prev;
      const stack = future.current[prev.weekStart] ?? [];
      if (!stack.length) return prev;
      const next = stack.pop()!;
      future.current[prev.weekStart] = stack;
      (past.current[prev.weekStart] ??= []).push(snapshot(prev));
      bumpHistory();
      setDirty(true);
      return next;
    });
  }, []);

  const canUndo = !!draft && (past.current[draft.weekStart]?.length ?? 0) > 0;
  const canRedo = !!draft && (future.current[draft.weekStart]?.length ?? 0) > 0;

  const setProgress = useCallback((day: DayKey, activityId: string, value: number) => {
    mutateDraft((w) => ({
      ...w,
      progress: { ...w.progress, [day]: { ...w.progress[day], [activityId]: value } },
    }));
  }, [mutateDraft]);

  const updateActivity = useCallback((day: DayKey, activityId: string, patch: Partial<Activity>) => {
    mutateDraft((w) => ({
      ...w,
      template: {
        ...w.template,
        [day]: w.template[day].map((a) => (a.id === activityId ? { ...a, ...patch } : a)),
      },
    }));
  }, [mutateDraft]);

  const addActivity = useCallback((day: DayKey) => {
    mutateDraft((w) => {
      const newAct: Activity = {
        id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        label: "New activity",
        start: "",
        end: "",
      };
      return { ...w, template: { ...w.template, [day]: [...w.template[day], newAct] } };
    });
  }, [mutateDraft]);

  const removeActivity = useCallback((day: DayKey, activityId: string) => {
    mutateDraft((w) => {
      const { [activityId]: _, ...rest } = w.progress[day];
      return {
        ...w,
        template: { ...w.template, [day]: w.template[day].filter((a) => a.id !== activityId) },
        progress: { ...w.progress, [day]: rest },
      };
    });
  }, [mutateDraft]);

  const replaceWeekTemplate = useCallback((template: Record<DayKey, Activity[]>) => {
    mutateDraft(() => ({ weekStart: key, template, progress: emptyProgress() }));
  }, [key, mutateDraft]);

  const replaceDay = useCallback((day: DayKey, activities: Activity[]) => {
    mutateDraft((w) => ({
      ...w,
      template: { ...w.template, [day]: activities },
      // drop progress for removed activity ids
      progress: {
        ...w.progress,
        [day]: Object.fromEntries(
          Object.entries(w.progress[day] ?? {}).filter(([id]) =>
            activities.some((a) => a.id === id)
          )
        ),
      },
    }));
  }, [mutateDraft]);

  const copyPreviousWeek = useCallback(() => {
    const sortedKeys = Object.keys(store.weeks).sort();
    const prevKey = sortedKeys.filter((k) => k < key).pop();
    if (!prevKey) return false;
    mutateDraft(() => ({
      weekStart: key,
      template: cloneTemplate(store.weeks[prevKey].template),
      progress: emptyProgress(),
    }));
    return true;
  }, [key, store.weeks, mutateDraft]);

  const resetWeek = useCallback(() => {
    mutateDraft((w) => ({ ...w, progress: emptyProgress() }));
  }, [mutateDraft]);

  const saveWeek = useCallback(async () => {
    if (!draft) return false;
    if (isGuest) {
      const next = { ...store.weeks, [key]: { ...draft, weekStart: key } };
      saveGuestWeeks(next);
      setStore({ weeks: next });
      setDirty(false);
      return true;
    }
    if (!userId) return false;
    setSaving(true);
    try {
      const { error } = await supabase.from("weeks").upsert(
        {
          user_id: userId,
          week_start: key,
          template: draft.template as any,
          progress: draft.progress as any,
        },
        { onConflict: "user_id,week_start" }
      );
      if (error) throw error;
      setStore((prev) => ({
        ...prev,
        weeks: { ...prev.weeks, [key]: { ...draft, weekStart: key } },
      }));
      setDirty(false);
      return true;
    } finally {
      setSaving(false);
    }
  }, [userId, draft, key, isGuest, store.weeks]);

  const deleteWeek = useCallback(async () => {
    if (isGuest) {
      const { [key]: _, ...rest } = store.weeks;
      saveGuestWeeks(rest);
      setStore({ weeks: rest });
      initialisedKeys.current.delete(key);
      setDraft(null);
      return true;
    }
    if (!userId) return false;
    const { error } = await supabase
      .from("weeks")
      .delete()
      .eq("user_id", userId)
      .eq("week_start", key);
    if (error) return false;
    setStore((prev) => {
      const { [key]: _, ...rest } = prev.weeks;
      return { ...prev, weeks: rest };
    });
    initialisedKeys.current.delete(key);
    setDraft(null);
    return true;
  }, [userId, key, isGuest, store.weeks]);

  const deleteAllWeeks = useCallback(async () => {
    if (isGuest) {
      saveGuestWeeks({});
      setStore({ weeks: {} });
      initialisedKeys.current.clear();
      setDraft(null);
      return true;
    }
    if (!userId) return false;
    const { error } = await supabase.from("weeks").delete().eq("user_id", userId);
    if (error) return false;
    setStore({ weeks: {} });
    initialisedKeys.current.clear();
    setDraft(null);
    return true;
  }, [userId, isGuest]);

  const hasPreviousWeek = Object.keys(store.weeks).some((k) => k < key);

  return {
    store,
    week,
    savedWeek,
    dirty,
    saving,
    loading,
    setProgress,
    updateActivity,
    addActivity,
    removeActivity,
    copyPreviousWeek,
    resetWeek,
    replaceWeekTemplate,
    replaceDay,
    saveWeek,
    deleteWeek,
    deleteAllWeeks,
    hasPreviousWeek,
    weekStartDate: startOfWeek(currentDate),
    undo,
    redo,
    canUndo,
    canRedo,
  };
}

export const dayPercent = (week: WeekData | undefined, day: DayKey): number => {
  if (!week) return 0;
  const acts = week.template[day];
  if (!acts || !acts.length) return 0;
  const total = acts.reduce((sum, a) => sum + (week.progress[day][a.id] ?? 0), 0);
  return Math.round(total / acts.length);
};

export const weekPercent = (week: WeekData | undefined): number => {
  if (!week) return 0;
  const vals = DAYS.map((d) => dayPercent(week, d.key));
  return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
};
