// Default Jellu schedule extracted from the uploaded timetable.
// `time` kept for backwards-compat (start time). Prefer `start` + `end`.
export type Activity = {
  id: string;
  label: string;
  time?: string; // legacy / convenience start time "HH:MM"
  start?: string; // "HH:MM"
  end?: string; // "HH:MM"
};
export type DayKey = "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun";

export const DAYS: { key: DayKey; label: string; short: string; emoji: string }[] = [
  { key: "mon", label: "Monday", short: "Mon", emoji: "🌟" },
  { key: "tue", label: "Tuesday", short: "Tue", emoji: "🚀" },
  { key: "wed", label: "Wednesday", short: "Wed", emoji: "🌈" },
  { key: "thu", label: "Thursday", short: "Thu", emoji: "🌱" },
  { key: "fri", label: "Friday", short: "Fri", emoji: "🎉" },
  { key: "sat", label: "Saturday", short: "Sat", emoji: "⚽" },
  { key: "sun", label: "Sunday", short: "Sun", emoji: "🎨" },
];

const weekday = (labels: string[]): Activity[] =>
  labels.map((label, i) => ({ id: `${label}-${i}`, label }));

// Weekday timetable (same structure each Mon-Fri, with day-specific subjects)
const baseWeekday = [
  { time: "6:30", label: "Wakeup" },
  { time: "6:45", label: "Freshup (bath & morning routine)" },
  { time: "7:00", label: "Exercise" },
  { time: "7:30", label: "Reading (min 100 pages)" },
  { time: "8:15", label: "Revise Formulas" },
  { time: "8:30", label: "Bath and get ready" },
  { time: "9:00", label: "Breakfast" },
  { time: "9:30", label: "Play time" },
  { time: "10:00", label: "Eat and get ready for study" },
  { time: "10:30", label: "Maths practice — Sevenoaks 1" },
  { time: "11:30", label: "Maths correction & review" },
];

const monExtra = ["NVR test 2", "Comprehension 3", "Diagram", "Long math 2"];
const tueExtra = ["VR 2", "Cloze passage 1", "Addition", "Short math 2"];
const wedExtra = ["NVR 1", "Comprehension 3", "Mul and div", "Mental arithmetic 1"];
const thuExtra = ["VR 3", "Cloze passage 2", "Substitution", "Mental Maths 1"];
const friExtra = ["NVR 2", "Cloze passage 3", "Inequalities", "Mental arithmetic"];

const eveningWeekday = [
  { time: "16:00", label: "Dance time" },
  { time: "16:30", label: "Vocabulary" },
  { time: "17:00", label: "Mistakes review & correction" },
  { time: "18:00", label: "Maths / English mastery" },
  { time: "20:00", label: "Reading" },
];

const buildWeekday = (extras: string[]): Activity[] => {
  const rows: Activity[] = [
    ...baseWeekday.map((r, i) => ({ id: `wd-${i}`, ...r })),
    ...extras.map((label, i) => ({ id: `ex-${i}`, label, time: `13:${i * 15 + 0}`.padEnd(5, "0") })),
    ...eveningWeekday.map((r, i) => ({ id: `ev-${i}`, ...r })),
  ];
  return rows;
};

const weekend: Activity[] = [
  { id: "we-0", time: "15:00", label: "Chess / Foosball" },
  { id: "we-1", time: "15:30", label: "Dance" },
  { id: "we-2", time: "16:00", label: "VR 1" },
  { id: "we-3", time: "16:15", label: "Retake NVR 1" },
  { id: "we-4", time: "16:30", label: "Long math 1" },
  { id: "we-5", time: "17:00", label: "DMAS factorization" },
  { id: "we-6", time: "17:30", label: "Mental Arithmetic" },
  { id: "we-7", time: "17:45", label: "Comprehension 2" },
  { id: "we-8", time: "18:00", label: "Vocabulary" },
  { id: "we-9", time: "18:30", label: "Maths mastery" },
  { id: "we-10", time: "19:00", label: "Mistakes review & correction" },
];

export const DEFAULT_TEMPLATE: Record<DayKey, Activity[]> = {
  mon: buildWeekday(monExtra),
  tue: buildWeekday(tueExtra),
  wed: buildWeekday(wedExtra),
  thu: buildWeekday(thuExtra),
  fri: buildWeekday(friExtra),
  sat: weekend,
  sun: weekend,
};

// Helpers for week math
export function startOfWeek(d: Date): Date {
  const date = new Date(d);
  const day = date.getDay(); // 0 Sun .. 6 Sat
  const diff = (day === 0 ? -6 : 1 - day);
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

export function weekKey(d: Date): string {
  const s = startOfWeek(d);
  return `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, "0")}-${String(s.getDate()).padStart(2, "0")}`;
}

export function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

export function formatDate(d: Date): string {
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}
