import { useState } from "react";
import { ProgressStepper } from "./ProgressStepper";
import { ProgressRing } from "./ProgressRing";
import { Activity, DayKey, DAYS, addDays, formatDate } from "@/lib/planner-data";
import { dayPercent, WeekData } from "@/hooks/use-planner";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Pencil, Plus, Trash2, Check, X } from "lucide-react";

interface DayCardProps {
  dayKey: DayKey;
  date: Date;
  week: WeekData | undefined;
  isToday: boolean;
  onSet: (day: DayKey, activityId: string, value: number) => void;
  onUpdateActivity: (day: DayKey, activityId: string, patch: Partial<Activity>) => void;
  onAddActivity: (day: DayKey) => void;
  onRemoveActivity: (day: DayKey, activityId: string) => void;
}

const DAY_BG: Record<DayKey, string> = {
  mon: "bg-day-mon",
  tue: "bg-day-tue",
  wed: "bg-day-wed",
  thu: "bg-day-thu",
  fri: "bg-day-fri",
  sat: "bg-day-sat",
  sun: "bg-day-sun",
};

function ActivityRow({
  activity,
  value,
  onSetProgress,
  onUpdate,
  onRemove,
}: {
  activity: Activity;
  value: number;
  onSetProgress: (v: number) => void;
  onUpdate: (patch: Partial<Activity>) => void;
  onRemove: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [label, setLabel] = useState(activity.label);
  const [start, setStart] = useState(activity.start ?? activity.time ?? "");
  const [end, setEnd] = useState(activity.end ?? "");

  const start0 = activity.start ?? activity.time ?? "";

  const save = () => {
    onUpdate({ label: label.trim() || "Untitled", start, end, time: start });
    setEditing(false);
  };
  const cancel = () => {
    setLabel(activity.label);
    setStart(activity.start ?? activity.time ?? "");
    setEnd(activity.end ?? "");
    setEditing(false);
  };

  if (editing) {
    return (
      <li className="px-4 py-3 bg-muted/30 space-y-2">
        <Input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="Activity name"
          className="h-9 rounded-xl"
        />
        <div className="flex items-center gap-2">
          <div className="flex-1">
            <label className="text-[10px] uppercase font-bold text-muted-foreground">Start</label>
            <Input
              type="time"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="h-9 rounded-xl"
            />
          </div>
          <div className="flex-1">
            <label className="text-[10px] uppercase font-bold text-muted-foreground">End</label>
            <Input
              type="time"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="h-9 rounded-xl"
            />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive rounded-full"
            onClick={onRemove}
          >
            <Trash2 className="h-4 w-4 mr-1" /> Remove
          </Button>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" className="rounded-full" onClick={cancel}>
              <X className="h-4 w-4 mr-1" /> Cancel
            </Button>
            <Button size="sm" className="rounded-full" onClick={save}>
              <Check className="h-4 w-4 mr-1" /> Save
            </Button>
          </div>
        </div>
      </li>
    );
  }

  return (
    <li className="group flex items-center gap-2 px-4 py-3 hover:bg-muted/40 transition-smooth">
      {(start0 || activity.end) && (
        <span className="text-[11px] font-bold text-muted-foreground w-20 shrink-0 tabular-nums leading-tight">
          {start0 || "--:--"}
          {activity.end && (
            <>
              <br />
              <span className="text-muted-foreground/70">→ {activity.end}</span>
            </>
          )}
        </span>
      )}
      <span className={cn("flex-1 text-sm", value === 100 && "line-through text-muted-foreground")}>
        {activity.label}
      </span>
      <ProgressStepper value={value} onChange={onSetProgress} />
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-full opacity-0 group-hover:opacity-100 transition-smooth"
        onClick={() => setEditing(true)}
        aria-label="Edit activity"
      >
        <Pencil className="h-4 w-4" />
      </Button>
    </li>
  );
}

export function DayCard({
  dayKey,
  date,
  week,
  isToday,
  onSet,
  onUpdateActivity,
  onAddActivity,
  onRemoveActivity,
}: DayCardProps) {
  const meta = DAYS.find((d) => d.key === dayKey)!;
  const activities: Activity[] = week?.template[dayKey] ?? [];
  const pct = dayPercent(week, dayKey);

  return (
    <div
      className={cn(
        "rounded-3xl bg-card shadow-card overflow-hidden border-2 transition-bounce animate-pop-in",
        isToday ? "border-primary shadow-pop" : "border-transparent"
      )}
    >
      <div className={cn("relative px-5 py-4 text-white", DAY_BG[dayKey])}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{meta.emoji}</span>
              <h3 className="text-xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>
                {meta.label}
              </h3>
              {isToday && (
                <span className="text-[10px] uppercase tracking-wide bg-white/25 px-2 py-0.5 rounded-full font-bold">
                  Today
                </span>
              )}
            </div>
            <p className="text-sm text-white/85 mt-0.5">{formatDate(date)}</p>
          </div>
          <ProgressRing value={pct} size={68} stroke={8} />
        </div>
      </div>

      <ul className="divide-y divide-border">
        {activities.map((a) => {
          const v = week?.progress[dayKey][a.id] ?? 0;
          return (
            <ActivityRow
              key={a.id}
              activity={a}
              value={v}
              onSetProgress={(nv) => onSet(dayKey, a.id, nv)}
              onUpdate={(patch) => onUpdateActivity(dayKey, a.id, patch)}
              onRemove={() => onRemoveActivity(dayKey, a.id)}
            />
          );
        })}
        {activities.length === 0 && (
          <li className="px-4 py-6 text-center text-sm text-muted-foreground">
            No activities yet 🌟
          </li>
        )}
      </ul>

      <div className="px-4 py-3 border-t border-border bg-muted/20">
        <Button
          variant="ghost"
          size="sm"
          className="w-full rounded-full font-bold"
          onClick={() => onAddActivity(dayKey)}
        >
          <Plus className="h-4 w-4 mr-1" /> Add activity
        </Button>
      </div>
    </div>
  );
}

export { addDays };
