import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export function StudentNameSetup() {
  const { setStudentName } = useAuth();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await setStudentName(name.trim());
      toast.success(`Welcome, ${name.trim()}! 🌟`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 gradient-rainbow">
      <form
        onSubmit={submit}
        className="w-full max-w-md rounded-3xl bg-card shadow-pop p-8 text-center space-y-5"
      >
        <div className="text-6xl">👋</div>
        <div>
          <h2 className="text-2xl font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>
            What's the student's name?
          </h2>
          <p className="text-muted-foreground mt-2 text-sm">
            We'll show it across the app to personalise their week.
          </p>
        </div>
        <Input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Jellu"
          className="h-12 rounded-2xl text-center text-lg"
        />
        <Button type="submit" size="lg" className="w-full rounded-full font-bold" disabled={busy}>
          Continue
        </Button>
      </form>
    </div>
  );
}
