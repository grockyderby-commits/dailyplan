import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Loader2, Volume2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Store } from "@/hooks/use-planner";
import { useAuth } from "@/hooks/use-auth";

type Turn = { role: "user" | "assistant"; content: string };

interface Props {
  store: Store;
  onClose: () => void;
}

// Browser SpeechRecognition (Chrome/Edge/Safari)
const SR: any =
  (typeof window !== "undefined" &&
    ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)) || null;

export function VoiceChat({ store, onClose }: Props) {
  const { profile } = useAuth();
  const [turns, setTurns] = useState<Turn[]>([]);
  const [partial, setPartial] = useState("");
  const [listening, setListening] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [muted, setMuted] = useState(false);

  const recogRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const turnsRef = useRef<Turn[]>([]);
  const mutedRef = useRef(false);
  const restartTimer = useRef<number | null>(null);

  useEffect(() => { turnsRef.current = turns; }, [turns]);
  useEffect(() => { mutedRef.current = muted; }, [muted]);

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setSpeaking(false);
  };

  const stopListening = () => {
    if (restartTimer.current) { clearTimeout(restartTimer.current); restartTimer.current = null; }
    if (recogRef.current) {
      try { recogRef.current.onend = null; recogRef.current.stop(); } catch {}
      recogRef.current = null;
    }
    setListening(false);
    setPartial("");
  };

  const speak = async (text: string) => {
    if (mutedRef.current) return;
    stopAudio();
    setSpeaking(true);
    try {
      const { data, error } = await supabase.functions.invoke("tts", { body: { text } });
      if (error) throw error;
      const audio = new Audio(`data:${data.mime};base64,${data.audio}`);
      audioRef.current = audio;
      await new Promise<void>((resolve) => {
        audio.onended = () => resolve();
        audio.onerror = () => resolve();
        audio.play().catch(() => resolve());
      });
    } catch (e: any) {
      toast.error(e?.context?.error || e?.message || "Voice playback failed");
    } finally {
      setSpeaking(false);
      audioRef.current = null;
    }
  };

  const sendToAI = async (userText: string) => {
    const next: Turn[] = [...turnsRef.current, { role: "user", content: userText }];
    setTurns(next);
    setThinking(true);
    try {
      const keys = Object.keys(store.weeks).sort();
      const week = keys.length ? store.weeks[keys[keys.length - 1]] : null;
      const { data, error } = await supabase.functions.invoke("voice-chat", {
        body: {
          messages: next,
          studentName: profile?.student_name,
          weekContext: week ? { weekStart: week.weekStart, template: week.template, progress: week.progress } : null,
        },
      });
      if (error) throw error;
      const reply = (data?.reply as string) ?? "";
      setTurns((t) => [...t, { role: "assistant", content: reply }]);
      await speak(reply);
      // Auto-resume listening after assistant finishes
      if (!mutedRef.current) startListening();
    } catch (e: any) {
      toast.error(e?.context?.error || e?.message || "AI failed");
    } finally {
      setThinking(false);
    }
  };

  const startListening = () => {
    if (!SR) {
      toast.error("Voice input isn't supported in this browser. Try Chrome.");
      return;
    }
    if (recogRef.current || speaking || thinking) return;
    const r = new SR();
    r.lang = "en-US";
    r.continuous = false;
    r.interimResults = true;

    let finalText = "";
    r.onresult = (ev: any) => {
      let interim = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const res = ev.results[i];
        if (res.isFinal) finalText += res[0].transcript;
        else interim += res[0].transcript;
      }
      setPartial(interim || finalText);
    };
    r.onerror = (ev: any) => {
      if (ev.error === "no-speech" || ev.error === "aborted") return;
      console.error("SR error", ev.error);
    };
    r.onend = () => {
      setListening(false);
      const text = finalText.trim();
      setPartial("");
      recogRef.current = null;
      if (text && !mutedRef.current) {
        sendToAI(text);
      } else if (!mutedRef.current) {
        // Quick restart if we got nothing
        restartTimer.current = window.setTimeout(() => startListening(), 300);
      }
    };

    try {
      r.start();
      recogRef.current = r;
      setListening(true);
    } catch (e) {
      console.error(e);
    }
  };

  const toggleMute = () => {
    if (muted) {
      setMuted(false);
      startListening();
    } else {
      setMuted(true);
      stopListening();
      stopAudio();
    }
  };

  // Greet on mount
  useEffect(() => {
    const greet = `Hi${profile?.student_name ? " " + profile.student_name : ""}! I'm your study buddy. What would you like to talk about today?`;
    setTurns([{ role: "assistant", content: greet }]);
    speak(greet).then(() => { if (!mutedRef.current) startListening(); });
    return () => { stopListening(); stopAudio(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const status = speaking ? "Speaking…" : thinking ? "Thinking…" : listening ? "Listening…" : muted ? "Muted" : "Idle";

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
      <div className="w-full max-w-md bg-card rounded-3xl shadow-2xl border-2 border-primary/20 overflow-hidden">
        <div className="px-5 py-4 flex items-center justify-between border-b border-border bg-gradient-to-r from-primary/10 to-transparent">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full gradient-rainbow flex items-center justify-center shadow-soft ${speaking ? "animate-pulse" : ""}`}>
              <Volume2 className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>Voice chat</p>
              <p className="text-xs text-muted-foreground">{status}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="rounded-full" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-5 max-h-[50vh] overflow-y-auto space-y-3">
          {turns.map((t, i) => (
            <div key={i} className={`flex ${t.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${
                t.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
              }`}>
                {t.content}
              </div>
            </div>
          ))}
          {partial && (
            <div className="flex justify-end">
              <div className="max-w-[85%] rounded-2xl px-4 py-2.5 text-sm bg-primary/40 text-primary-foreground italic">
                {partial}…
              </div>
            </div>
          )}
          {thinking && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-2xl px-4 py-2.5 text-sm flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" /> thinking…
              </div>
            </div>
          )}
        </div>

        <div className="px-5 py-4 border-t border-border flex items-center justify-center gap-3 bg-muted/20">
          <Button
            size="lg"
            onClick={toggleMute}
            className={`rounded-full h-14 w-14 p-0 ${muted ? "bg-muted text-foreground hover:bg-muted/80" : "gradient-rainbow text-white"} ${listening ? "animate-pulse" : ""}`}
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </Button>
          {speaking && (
            <Button variant="outline" size="sm" className="rounded-full" onClick={stopAudio}>
              Stop talking
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
