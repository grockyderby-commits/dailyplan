import { cn } from "@/lib/utils";
import { Check, Circle } from "lucide-react";

const STEPS = [0, 25, 50, 75, 100] as const;

interface ProgressStepperProps {
  value: number;
  onChange: (v: number) => void;
  className?: string;
}

export function ProgressStepper({ value, onChange, className }: ProgressStepperProps) {
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      {STEPS.map((step) => {
        const active = value >= step && step > 0;
        const isCurrent = value === step;
        const tier =
          step === 0
            ? "bg-muted text-muted-foreground"
            : step <= 25
            ? "bg-primary text-primary-foreground"
            : step <= 50
            ? "bg-accent text-accent-foreground"
            : step <= 75
            ? "bg-secondary text-secondary-foreground"
            : "bg-success text-success-foreground";
        return (
          <button
            key={step}
            type="button"
            onClick={() => onChange(step)}
            className={cn(
              "h-9 min-w-9 px-2 rounded-full text-xs font-bold transition-bounce border-2 border-transparent flex items-center justify-center",
              active ? tier + " shadow-soft" : "bg-muted text-muted-foreground hover:bg-muted/70",
              isCurrent && "ring-2 ring-offset-2 ring-primary scale-110"
            )}
            aria-label={`Set progress ${step}%`}
          >
            {step === 100 && active ? <Check className="h-4 w-4" /> : step === 0 ? <Circle className="h-3 w-3" /> : `${step}`}
          </button>
        );
      })}
    </div>
  );
}
