import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Sparkles, Upload, Wand2, Loader2, Lightbulb, FileText, Volume2, Lock, Square, Mic, MessageSquare, Send,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Activity, DAYS, DayKey } from "@/lib/planner-data";
import type { Store, WeekData } from "@/hooks/use-planner";
import * as XLSX from "xlsx";
import { useAuth } from "@/hooks/use-auth";
import { VoiceChat } from "@/components/VoiceChat";

type ParsedDayItem = { label: string; start?: string; end?: string };
type ParseResponse = { days: Record<DayKey, ParsedDayItem[]>; notes?: string };
type ChatEditResponse = { days: Record<DayKey, ParsedDayItem[]>; reply: string };
type InsightsResponse = {
  summary: string;
  strengths: string[];
  improvements: string[];
  recommendations: string[];
};

interface Props {
  store: Store;
  week?: WeekData;
  onApplySchedule: (template: Record<DayKey, Activity[]>) => void;
  onReplaceDay: (day: DayKey, activities: Activity[]) => void;
}

type ChatMsg = { role: "user" | "ai"; text: string };

export function SmartAssistant({ store, week, onApplySchedule, onReplaceDay }: Props) {
  const { profile } = useAuth();
  const isPaid = !!profile?.is_paid;
  const [open, setOpen] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [text, setText] = useState("");
  const [busyParse, setBusyParse] = useState(false);
  const [busyInsights, setBusyInsights] = useState(false);
  const [busyVoice, setBusyVoice] = useState(false);
  const [insights, setInsights] = useState<InsightsResponse | null>(null);
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [busyChat, setBusyChat] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const requirePaid = () => {
    if (!isPaid) {
      toast.error("AI features are available on the paid plan ✨");
      return false;
    }
    return true;
  };

  const handleFile = async (file: File) => {
    try {
      const lower = file.name.toLowerCase();
      let extracted = "";
      if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: "array" });
        const parts: string[] = [];
        wb.SheetNames.forEach((n) => {
          parts.push(`# Sheet: ${n}\n` + XLSX.utils.sheet_to_csv(wb.Sheets[n]));
        });
        extracted = parts.join("\n\n");
      } else {
        extracted = await file.text();
      }
      setText((prev) => (prev ? prev + "\n\n" : "") + extracted.slice(0, 20000));
      toast.success(`Loaded ${file.name} ✨`);
    } catch {
      toast.error("Couldn't read that file");
    }
  };

  const runParse = async () => {
    if (!requirePaid()) return;
    if (!text.trim()) return toast.info("Paste a schedule or upload a file first");
    setBusyParse(true);
    try {
      const { data, error } = await supabase.functions.invoke("smart-planner", {
        body: { mode: "parse", text },
      });
      if (error) throw error;
      const parsed = data as ParseResponse;
      const template: Record<DayKey, Activity[]> = DAYS.reduce((acc, d) => {
        const items = parsed.days?.[d.key] ?? [];
        acc[d.key] = items.map((it, i) => ({
          id: `ai-${d.key}-${Date.now()}-${i}`,
          label: it.label,
          start: it.start || "",
          end: it.end || "",
          time: it.start || "",
        }));
        return acc;
      }, {} as Record<DayKey, Activity[]>);
      onApplySchedule(template);
      toast.success("Schedule built! Don't forget to Save ✨");
    } catch (e: any) {
      toast.error(e?.context?.error || e?.message || "Failed to parse");
    } finally {
      setBusyParse(false);
    }
  };

  const sendChat = async () => {
    if (!requirePaid()) return;
    const msg = chatInput.trim();
    if (!msg) return;
    setChat((c) => [...c, { role: "user", text: msg }]);
    setChatInput("");
    setBusyChat(true);
    try {
      // Compact current week as plain {day: [{label, start, end}]}
      const compact: Record<string, ParsedDayItem[]> = {};
      DAYS.forEach((d) => {
        compact[d.key] = (week?.template[d.key] ?? []).map((a) => ({
          label: a.label,
          start: a.start || a.time || "",
          end: a.end || "",
        }));
      });
      const { data, error } = await supabase.functions.invoke("smart-planner", {
        body: { mode: "chat_edit", message: msg, days: compact },
      });
      if (error) throw error;
      const resp = data as ChatEditResponse;
      DAYS.forEach((d) => {
        const items = resp.days?.[d.key] ?? [];
        const acts: Activity[] = items.map((it, i) => ({
          id: `chat-${d.key}-${Date.now()}-${i}`,
          label: it.label,
          start: it.start || "",
          end: it.end || "",
          time: it.start || "",
        }));
        onReplaceDay(d.key, acts);
      });
      setChat((c) => [...c, { role: "ai", text: resp.reply || "Done! Review and Save." }]);
    } catch (e: any) {
      const m = e?.context?.error || e?.message || "Couldn't update the plan";
      setChat((c) => [...c, { role: "ai", text: m }]);
      toast.error(m);
    } finally {
      setBusyChat(false);
    }
  };

  const runInsights = async () => {
    if (!requirePaid()) return;
    setBusyInsights(true);
    try {
      const keys = Object.keys(store.weeks).sort().slice(-6);
      const weeks = keys.map((k) => {
        const w = store.weeks[k];
        return {
          weekStart: w.weekStart,
          days: DAYS.map((d) => ({
            day: d.key,
            activities: (w.template[d.key] ?? []).map((a) => ({
              label: a.label,
              completion: w.progress[d.key]?.[a.id] ?? 0,
            })),
          })),
        };
      });
      if (!weeks.length) return toast.info("Save a week first 🌱");
      const { data, error } = await supabase.functions.invoke("smart-planner", {
        body: { mode: "insights", weeks },
      });
      if (error) throw error;
      setInsights(data as InsightsResponse);
    } catch (e: any) {
      toast.error(e?.context?.error || e?.message || "Failed to get insights");
    } finally {
      setBusyInsights(false);
    }
  };

  const speak = async (text: string) => {
    if (!requirePaid()) return;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setBusyVoice(true);
    try {
      const { data, error } = await supabase.functions.invoke("tts", { body: { text } });
      if (error) throw error;
      const audio = new Audio(`data:${data.mime};base64,${data.audio}`);
      audioRef.current = audio;
      audio.onended = () => setBusyVoice(false);
      await audio.play();
    } catch (e: any) {
      toast.error(e?.context?.error || e?.message || "Voice failed");
      setBusyVoice(false);
    }
  };

  const stopSpeaking = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setBusyVoice(false);
  };

  const insightsAsText = (i: InsightsResponse) =>
    [
      i.summary,
      i.strengths.length ? "Strengths: " + i.strengths.join(", ") : "",
      i.improvements.length ? "Areas to focus on: " + i.improvements.join(", ") : "",
      i.recommendations.length ? "Recommendations: " + i.recommendations.join(". ") : "",
    ].filter(Boolean).join(". ");

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 mt-4">
      <div className="rounded-3xl bg-card shadow-card overflow-hidden border-2 border-primary/20">
        <button
          onClick={() => setOpen((o) => !o)}
          className="w-full flex items-center justify-between gap-3 px-5 py-4 hover:bg-muted/30 transition-smooth"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl gradient-rainbow flex items-center justify-center shadow-soft">
              <Wand2 className="h-5 w-5 text-white" />
            </div>
            <div className="text-left">
              <p className="font-bold flex items-center gap-2" style={{ fontFamily: "Fredoka, sans-serif" }}>
                Smart Assistant
                {!isPaid && (
                  <span className="text-[10px] uppercase tracking-wide bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                    <Lock className="h-3 w-3" /> Paid
                  </span>
                )}
              </p>
              <p className="text-xs text-muted-foreground">
                Chat to add tasks, AI schedule builder, insights & voice
              </p>
            </div>
          </div>
          <Sparkles className="h-5 w-5 text-primary" />
        </button>

        {open && (
          <div className="border-t border-border p-5 space-y-5">
            {!isPaid && (
              <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 text-sm text-amber-900">
                <p className="font-bold mb-1 flex items-center gap-1.5">
                  <Lock className="h-4 w-4" /> Upgrade to use AI features
                </p>
                <p>
                  AI scheduling, chat task editing, weekly insights and voice are paid features.
                </p>
              </div>
            )}

            {/* Chat-based task add */}
            <div className={`space-y-3 ${!isPaid ? "opacity-60 pointer-events-none" : ""}`}>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-primary" />
                <h4 className="font-bold text-sm uppercase tracking-wide">Chat with your planner</h4>
              </div>
              <p className="text-xs text-muted-foreground">
                Try: "Add 30 min piano on Wednesday at 4pm" · "Move maths to morning" · "Remove dance Saturday". The AI will rearrange the day to avoid clashes.
              </p>
              <div className="rounded-2xl bg-muted/40 p-3 max-h-56 overflow-auto space-y-2">
                {chat.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-3">
                    Start a conversation — your week updates automatically.
                  </p>
                )}
                {chat.map((m, i) => (
                  <div
                    key={i}
                    className={`text-sm rounded-2xl px-3 py-2 max-w-[85%] ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground ml-auto"
                        : "bg-card border border-border"
                    }`}
                  >
                    {m.text}
                  </div>
                ))}
                {busyChat && (
                  <div className="text-sm rounded-2xl px-3 py-2 bg-card border border-border inline-flex items-center gap-2">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> Rearranging your week…
                  </div>
                )}
              </div>
              <form
                className="flex items-center gap-2"
                onSubmit={(e) => { e.preventDefault(); sendChat(); }}
              >
                <Input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask to add, move, or remove a task…"
                  className="rounded-full"
                  disabled={busyChat}
                />
                <Button type="submit" size="icon" className="rounded-full shrink-0" disabled={busyChat || !chatInput.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>

            <div className={`rounded-2xl gradient-rainbow p-4 flex items-center justify-between gap-3 ${!isPaid ? "opacity-60 pointer-events-none" : ""}`}>
              <div className="text-white">
                <p className="font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>Talk to your AI buddy</p>
                <p className="text-xs opacity-90">Real two-way voice — speak naturally.</p>
              </div>
              <Button size="sm" variant="secondary" className="rounded-full font-bold shrink-0" onClick={() => setVoiceOpen(true)}>
                <Mic className="h-4 w-4 mr-1.5" /> Start voice chat
              </Button>
            </div>

            <div className={`space-y-3 ${!isPaid ? "opacity-60 pointer-events-none" : ""}`}>
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                <h4 className="font-bold text-sm uppercase tracking-wide">
                  Build week from a file or notes
                </h4>
              </div>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste a schedule (Excel rows, notes, or a timetable)…"
                className="min-h-[120px] rounded-2xl"
              />
              <div className="flex flex-wrap items-center gap-2">
                <input
                  ref={fileRef}
                  type="file"
                  accept=".xlsx,.xls,.csv,.txt,.md,text/plain"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleFile(f);
                    if (fileRef.current) fileRef.current.value = "";
                  }}
                />
                <Button variant="outline" size="sm" className="rounded-full" onClick={() => fileRef.current?.click()}>
                  <Upload className="h-4 w-4 mr-1.5" /> Upload Excel / text
                </Button>
                <Button size="sm" className="rounded-full font-bold" onClick={runParse} disabled={busyParse}>
                  {busyParse ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" />Building…</> : <><Wand2 className="h-4 w-4 mr-1.5" />Build my week with AI</>}
                </Button>
                <Button size="sm" variant="ghost" className="rounded-full" onClick={() => speak("Hi! Paste your schedule or upload a file, then tap Build my week. I will fill the planner for you. Don't forget to save when you're done.")} disabled={busyVoice}>
                  <Volume2 className="h-4 w-4 mr-1.5" /> Hear how it works
                </Button>
                {text && <Button variant="ghost" size="sm" className="rounded-full" onClick={() => setText("")}>Clear</Button>}
              </div>
            </div>

            <div className={`space-y-3 pt-2 border-t border-border ${!isPaid ? "opacity-60 pointer-events-none" : ""}`}>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-primary" />
                  <h4 className="font-bold text-sm uppercase tracking-wide">Weekly insights</h4>
                </div>
                <div className="flex items-center gap-2">
                  {busyVoice ? (
                    <Button size="sm" variant="ghost" className="rounded-full" onClick={stopSpeaking}>
                      <Square className="h-4 w-4 mr-1.5" /> Stop
                    </Button>
                  ) : insights ? (
                    <Button size="sm" variant="ghost" className="rounded-full" onClick={() => speak(insightsAsText(insights))}>
                      <Volume2 className="h-4 w-4 mr-1.5" /> Read aloud
                    </Button>
                  ) : null}
                  <Button size="sm" variant="secondary" className="rounded-full font-bold" onClick={runInsights} disabled={busyInsights}>
                    {busyInsights ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" />Thinking…</> : <><Sparkles className="h-4 w-4 mr-1.5" />Get my insights</>}
                  </Button>
                </div>
              </div>

              {insights && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="md:col-span-2 rounded-2xl bg-muted/40 p-4">
                    <p className="text-sm">{insights.summary}</p>
                  </div>
                  <InsightCol title="✨ Strengths" items={insights.strengths} tone="bg-day-fri/15" />
                  <InsightCol title="💪 Needs focus" items={insights.improvements} tone="bg-day-tue/15" />
                  <div className="md:col-span-2 rounded-2xl bg-day-sat/10 p-4">
                    <p className="font-bold text-xs uppercase tracking-wide mb-2">🌟 Recommendations</p>
                    <ul className="text-sm space-y-1.5 list-disc list-inside">
                      {insights.recommendations.map((r, i) => <li key={i}>{r}</li>)}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      {voiceOpen && <VoiceChat store={store} onClose={() => setVoiceOpen(false)} />}
    </div>
  );
}

function InsightCol({ title, items, tone }: { title: string; items: string[]; tone: string }) {
  return (
    <div className={`rounded-2xl p-4 ${tone}`}>
      <p className="font-bold text-xs uppercase tracking-wide mb-2">{title}</p>
      <ul className="text-sm space-y-1.5 list-disc list-inside">
        {items?.length ? items.map((s, i) => <li key={i}>{s}</li>) : <li className="text-muted-foreground">—</li>}
      </ul>
    </div>
  );
}
